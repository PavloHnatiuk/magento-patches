Magento patch SUPEE-6788
Refer to https://magentary.com/kb/install-supee-6788-without-ssh/ for installation instructions.
